# Hispanic Heritage Historical Data Explorer

A single-file Streamlit classroom app for retrieving World Bank historical indicators, editing a clearly labeled scenario table, fitting centered-time polynomial models, comparing countries, exploring functions/calculus, and exporting CSV, Excel, and PDF reports.

## Research question and choices
The app starts with a sample research question and lets the team edit it. Choose a featured country, indicator, and mathematics pathway in the interface. Supported countries: Mexico, Brazil, Argentina, Colombia, Chile, Peru, Venezuela, Ecuador, and Uruguay. Brazil is included as a Latin American comparison country; Latin American and Hispanic are not identical categories.

## Files
- `app.py` — complete app
- `requirements.txt` — minimal unpinned direct dependencies
- `sources.md` — indicator definitions, API endpoints, and limitations

## Run locally
Use Python 3.10 or newer in a virtual environment.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python -m streamlit run app.py
```

The equivalent short command `streamlit run app.py` also works.

## GitHub + Streamlit Community Cloud
1. Create a GitHub repository and upload `app.py`, `requirements.txt`, `README.md`, and `sources.md` to the repository root.
2. Commit and push the files.
3. Open [Streamlit Community Cloud](https://share.streamlit.io/), sign in, and choose **Create app**.
4. Select the repository, branch, and `app.py` as the main file.
5. Deploy. The app needs outbound network access to `api.worldbank.org`. No credentials or secrets are required.
6. After changes, commit and push; Streamlit Cloud will redeploy the app.

## Render
Create a **Python Web Service** connected to the GitHub repository.

- **Build command:** `pip install -r requirements.txt`
- **Start command:** `python -m streamlit run app.py --server.address=0.0.0.0 --server.port=$PORT`

If the service fails to start, check Render logs for dependency installation, Python version, port binding, and outbound API access.

## Verification checklist
- **Source accuracy:** compare an API value and its year with the official World Bank indicator page/API URL in `sources.md`.
- **Coverage:** ensure displayed actual range and non-missing count reflect the returned data, not a promised 70 rows.
- **Editing/reset:** change a value; confirm the scenario label appears and exports reflect it; press **Reset to source** and verify source values return.
- **Validation:** try a duplicate year, non-numeric value, blank value, out-of-range life expectancy, and fewer than degree + 1 distinct years. Fitting should be blocked with an explanation.
- **Fit:** compare displayed equation with a calculator or independent polynomial fit; verify base year, degree, R², MAE, residuals, and observation count.
- **Single/batch agreement:** calculate a year individually and in a batch. Values should match to displayed precision.
- **Invalid inputs/API failure:** use invalid custom years; test offline or temporarily block the API in a development environment. The app should show a clear error and never insert random values.
- **Controls:** change country, indicator, degree, graph sample increment, horizon, comparison countries, pathway, context, function, interval, point, and graph toggles; confirm their intended output changes.
- **Exports:** open the CSV in a text editor, Excel workbook in a spreadsheet application, and PDF in a PDF reader. Confirm file formats and selected metadata.
- **Deployment:** inspect the deployed app logs and test a cold start, country/indicator switch, editing, and all downloads.

## Known limitations
The code was syntax-compiled while packaging, but no claim is made that every API response, deployment environment, or interactive combination was end-to-end tested here. The app needs internet access for the World Bank API. Polynomial forecasts are not causal explanations or validated prediction intervals. Symbolic critical-point analysis is partly numerical and may not classify complicated functions perfectly. Visual simulation is an illustrative classroom display, not a physical/medical model.


## Copy-and-paste statistics tool

The app includes a **Mean and Standard Deviation** section. Paste values separated by commas, spaces, semicolons, tabs, or new lines. It reports the count, mean, population standard deviation, sample standard deviation (when at least two values are present), minimum, and maximum. Results can be downloaded as CSV.

### Copying and pasting the app code
1. Open `app.py` in GitHub or a text editor.
2. Select all and copy the code, or use the file's **Raw** view on GitHub and copy it.
3. Paste it into your repository's `app.py`, then commit the change so Render can redeploy.
4. To paste data into the statistics tool, copy the numbers from a spreadsheet and paste them into the text area. Rows/columns copied from spreadsheets are supported because tabs and new lines are separators.
