# Sources and indicator notes

## Official World Bank API
API pattern:
`https://api.worldbank.org/v2/country/{ISO3}/indicator/{INDICATOR_CODE}?date={START}:{END}&format=json`

The app requests the current calendar year minus 70 through current year minus 1, inclusive. As of 2026, that requested interval is 1956–2025. The actual returned range and non-missing observation count are calculated from the API response; coverage varies by indicator and country.

Country API identifiers:
- Mexico `MEX`
- Brazil `BRA`
- Argentina `ARG`
- Colombia `COL`
- Chile `CHL`
- Peru `PER`
- Venezuela `VEN`
- Ecuador `ECU`
- Uruguay `URY`

Brazil is included as a Latin American comparison country. “Latin American” and “Hispanic” are not interchangeable categories.

## Indicators
Each source link below opens the official World Bank indicator page. Values may be revised and coverage may vary.

| Indicator | Code | Units / interpretation |
|---|---|---|
| Life expectancy at birth | `SP.DYN.LE00.IN` | Years; expected lifespan under current mortality patterns |
| Unemployment, national estimate | `SL.UEM.TOTL.NE.ZS` | Percent of labor force; national estimate |
| GDP per capita (current US$) | `NY.GDP.PCAP.CD` | Current US dollars per person; not average wealth or household income |
| Crude birth rate | `SP.DYN.CBRT.IN` | Births per 1,000 people per year; a rate, not a count |
| Net migration | `SM.POP.NETM` | Net number of migrants; not an emigration count |
| Intentional homicide rate | `VC.IHR.PSRC.P5` | Intentional homicides per 100,000 people |
| Consumer price inflation | `FP.CPI.TOTL.ZG` | Annual percent change in consumer price index |
| Central government debt | `GC.DOD.TOTL.GD.ZS` | Percent of GDP |
| Total reserves including gold | `FI.RES.TOTL.CD` | Current US dollars |
| External balance on goods and services | `NE.RSB.GNFS.ZS` | Percent of GDP; not the full current account |

Official pages:
- [Life expectancy](https://data.worldbank.org/indicator/SP.DYN.LE00.IN)
- [Unemployment, national estimate](https://data.worldbank.org/indicator/SL.UEM.TOTL.NE.ZS)
- [GDP per capita](https://data.worldbank.org/indicator/NY.GDP.PCAP.CD)
- [Crude birth rate](https://data.worldbank.org/indicator/SP.DYN.CBRT.IN)
- [Net migration](https://data.worldbank.org/indicator/SM.POP.NETM)
- [Intentional homicide rate](https://data.worldbank.org/indicator/VC.IHR.PSRC.P5)
- [Consumer price inflation](https://data.worldbank.org/indicator/FP.CPI.TOTL.ZG)
- [Central government debt](https://data.worldbank.org/indicator/GC.DOD.TOTL.GD.ZS)
- [Total reserves including gold](https://data.worldbank.org/indicator/FI.RES.TOTL.CD)
- [External balance on goods and services](https://data.worldbank.org/indicator/NE.RSB.GNFS.ZS)

## Methods
- Missing API values remain missing and are not replaced with invented values.
- A centered-time polynomial is fitted using `t = year - base_year`, where the base year is the first valid working-table year.
- R² and MAE are in-sample scores unless explicitly labeled chronological holdout.
- Residuals are observed minus fitted values.
- Extrapolations are not clipped and should be treated cautiously.
- No 95% prediction interval is claimed. MAE and residuals are descriptive error measures.
- Editing the working table creates a user-modified scenario; reset returns it to the source response.
- Historical associations do not establish causes.
